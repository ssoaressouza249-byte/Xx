package com.raylan.owerotmx.shizuku

import android.content.pm.PackageManager
import com.raylan.owerotmx.model.FpsMode
import com.raylan.owerotmx.model.LogLevel
import com.raylan.owerotmx.model.ShizukuStatus
import java.io.BufferedReader
import java.io.InputStreamReader
import rikka.shizuku.Shizuku

data class CommandExecutionResult(
    val command: String,
    val exitCode: Int,
    val output: String,
    val error: String,
    val success: Boolean,
)

object ShizukuExecutor {

    const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001
    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    const val ROBLOX_PACKAGE = "com.roblox.client"

    private var listenersRegistered = false
    private var onStatusChangedCallback: ((ShizukuStatus) -> Unit)? = null

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        onStatusChangedCallback?.invoke(checkStatus())
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        onStatusChangedCallback?.invoke(ShizukuStatus.DISCONNECTED)
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                val status = if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    ShizukuStatus.CONNECTED
                } else {
                    ShizukuStatus.PERMISSION_NEEDED
                }
                onStatusChangedCallback?.invoke(status)
            }
        }

    fun registerListeners(onStatusChanged: ((ShizukuStatus) -> Unit)? = null) {
        onStatusChangedCallback = onStatusChanged
        if (!listenersRegistered) {
            runCatching {
                Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
                Shizuku.addBinderDeadListener(binderDeadListener)
                Shizuku.addRequestPermissionResultListener(permissionResultListener)
                listenersRegistered = true
            }
        }
    }

    fun unregisterListeners() {
        if (listenersRegistered) {
            runCatching {
                Shizuku.removeBinderReceivedListener(binderReceivedListener)
                Shizuku.removeBinderDeadListener(binderDeadListener)
                Shizuku.removeRequestPermissionResultListener(permissionResultListener)
                listenersRegistered = false
                onStatusChangedCallback = null
            }
        }
    }

    fun checkStatus(): ShizukuStatus {
        registerListeners(onStatusChangedCallback)
        return runCatching {
            if (!Shizuku.pingBinder()) {
                ShizukuStatus.DISCONNECTED
            } else if (Shizuku.isPreV11()) {
                ShizukuStatus.DISCONNECTED
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                ShizukuStatus.CONNECTED
            } else {
                ShizukuStatus.PERMISSION_NEEDED
            }
        }.getOrDefault(ShizukuStatus.DISCONNECTED)
    }

    fun requestPermissionIfNeeded(): Boolean {
        registerListeners(onStatusChangedCallback)
        return runCatching {
            if (Shizuku.pingBinder() && !Shizuku.isPreV11()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
                    true
                } else {
                    false
                }
            } else {
                false
            }
        }.getOrDefault(false)
    }

    fun runShellCommand(command: String): CommandExecutionResult {
        return runCatching {
            if (!Shizuku.pingBinder()) {
                return CommandExecutionResult(
                    command = command,
                    exitCode = -1,
                    output = "",
                    error = "Shizuku binder desconectado",
                    success = false,
                )
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                return CommandExecutionResult(
                    command = command,
                    exitCode = -1,
                    output = "",
                    error = "Permissão Shizuku não concedida",
                    success = false,
                )
            }

            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java,
            ).apply { isAccessible = true }

            val process = newProcessMethod.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText().trim() }
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText().trim() }
            val exitCode = process.waitFor()
            runCatching { process.destroy() }

            CommandExecutionResult(
                command = command,
                exitCode = exitCode,
                output = stdout,
                error = stderr,
                success = exitCode == 0,
            )
        }.getOrElse { throwable ->
            CommandExecutionResult(
                command = command,
                exitCode = -1,
                output = "",
                error = throwable.message ?: "Erro inesperado ao executar Shizuku.newProcess",
                success = false,
            )
        }
    }

    fun buildFpsCommands(packageName: String, mode: FpsMode): List<String> {
        val fps = mode.fpsValue
        val baseCommands = mutableListOf(
            "cmd game mode performance $packageName",
            "cmd game set --fps $fps $packageName",
            "settings put system peak_refresh_rate $fps.0",
            "settings put system min_refresh_rate $fps.0",
            "setprop debug.hwui.fps_divisor 1",
        )

        if (mode.isVip) {
            baseCommands.addAll(
                listOf(
                    "cmd thermalservice override-status 0",
                    "cmd activity kill-all",
                    "settings put global window_animation_scale 0.0",
                    "settings put global transition_animation_scale 0.0",
                    "settings put global animator_duration_scale 0.0",
                    "setprop debug.egl.hw 1",
                    "setprop debug.sf.hw 1",
                )
            )
        }

        return baseCommands
    }

    fun buildRobloxFastFlagsJson(mode: FpsMode): String {
        return if (mode.isVip) {
            """{"DFIntTaskSchedulerTargetFps": 400, "FFlagDebugForceFutureIsBrightPhase3": false, "DFIntTextureQualityOverride": 1}"""
        } else {
            """{"DFIntTaskSchedulerTargetFps": ${mode.fpsValue}}"""
        }
    }

    fun buildRobloxFastFlagsCommand(packageName: String, jsonPayload: String): String {
        val dir = "/sdcard/Android/data/$packageName/files/ClientSettings"
        val filePath = "$dir/ClientAppSettings.json"
        val escapedJson = jsonPayload.replace("\"", "\\\"")
        return "mkdir -p '$dir' && printf '%s' '$escapedJson' > '$filePath'"
    }

    fun buildRestoreCommands(packageName: String?): List<Pair<LogLevel, String>> {
        val list = mutableListOf<Pair<LogLevel, String>>()
        if (!packageName.isNullOrBlank()) {
            list.add(LogLevel.CMD to "cmd game mode standard $packageName")
            list.add(LogLevel.CMD to "cmd game reset $packageName")
        }
        list.add(LogLevel.CMD to "settings delete system peak_refresh_rate")
        list.add(LogLevel.CMD to "settings delete system min_refresh_rate")
        list.add(LogLevel.CMD to "settings put global window_animation_scale 1.0")
        list.add(LogLevel.CMD to "settings put global transition_animation_scale 1.0")
        list.add(LogLevel.CMD to "settings put global animator_duration_scale 1.0")
        list.add(LogLevel.CMD to "cmd thermalservice reset")
        if (packageName == ROBLOX_PACKAGE) {
            list.add(
                LogLevel.FLAG to "rm -f '/sdcard/Android/data/$ROBLOX_PACKAGE/files/ClientSettings/ClientAppSettings.json'"
            )
        }
        return list
    }
}
