package com.raylan.owerotmx.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Launch
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.owerotmx.R
import com.raylan.owerotmx.model.FpsMode
import com.raylan.owerotmx.model.InstalledAppInfo
import com.raylan.owerotmx.model.LogLevel
import com.raylan.owerotmx.model.ShizukuStatus
import com.raylan.owerotmx.model.TerminalLogEntry
import com.raylan.owerotmx.ui.theme.BgDeepBlack
import com.raylan.owerotmx.ui.theme.CardBorderSubtle
import com.raylan.owerotmx.ui.theme.CardSurface
import com.raylan.owerotmx.ui.theme.CardSurfaceElevated
import com.raylan.owerotmx.ui.theme.NeonRed
import com.raylan.owerotmx.ui.theme.NeonRedSoft
import com.raylan.owerotmx.ui.theme.StatusAmber
import com.raylan.owerotmx.ui.theme.TerminalBg
import com.raylan.owerotmx.ui.theme.TerminalGreen
import com.raylan.owerotmx.ui.theme.TextMuted
import com.raylan.owerotmx.ui.theme.TextPrimary
import com.raylan.owerotmx.ui.theme.TextSecondary
import com.raylan.owerotmx.ui.theme.VipGold
import com.raylan.owerotmx.ui.theme.VipGoldSoft

@Composable
fun HeaderSection(
  shizukuStatus: ShizukuStatus,
  isRestoring: Boolean,
  onRestoreDefault: () -> Unit,
  onStatusClick: () -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .background(CardSurface)
      .border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
      .padding(14.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(
            text = "OWER OTMX",
            style = MaterialTheme.typography.headlineMedium,
            color = TextPrimary,
          )
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(NeonRedSoft)
              .border(1.dp, NeonRed.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
              .padding(horizontal = 7.dp, vertical = 2.dp),
          ) {
            Text(
              text = stringResource(R.string.engine_version),
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 10.sp,
              color = NeonRed,
            )
          }
        }
      }

      OutlinedButton(
        onClick = onRestoreDefault,
        enabled = !isRestoring,
        modifier = Modifier
          .height(40.dp)
          .testTag("restore_default_button"),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, CardBorderSubtle),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
        colors = ButtonDefaults.outlinedButtonColors(
          containerColor = CardSurfaceElevated,
          contentColor = TextPrimary,
        ),
      ) {
        if (isRestoring) {
          CircularProgressIndicator(
            modifier = Modifier.size(14.dp),
            strokeWidth = 2.dp,
            color = NeonRed,
          )
        } else {
          Icon(
            imageVector = Icons.Filled.RestartAlt,
            contentDescription = stringResource(R.string.restore_default),
            tint = NeonRed,
            modifier = Modifier.size(16.dp),
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = stringResource(R.string.restore_default),
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          maxLines = 1,
        )
      }
    }

    val (dotColor, statusText) = when (shizukuStatus) {
      ShizukuStatus.CONNECTED -> TerminalGreen to stringResource(R.string.shizuku_connected)
      ShizukuStatus.PERMISSION_NEEDED -> StatusAmber to stringResource(R.string.shizuku_permission_needed)
      ShizukuStatus.DISCONNECTED -> NeonRed to stringResource(R.string.shizuku_disconnected)
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(10.dp))
        .background(BgDeepBlack)
        .border(1.dp, dotColor.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
        .clickable(onClick = onStatusClick)
        .padding(horizontal = 12.dp, vertical = 8.dp)
        .testTag("shizuku_status_pill"),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Box(
          modifier = Modifier
            .size(9.dp)
            .clip(CircleShape)
            .background(dotColor),
        )
        Text(
          text = statusText,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.SemiBold,
          fontSize = 12.sp,
          color = dotColor,
        )
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.Security,
          contentDescription = null,
          tint = TextMuted,
          modifier = Modifier.size(14.dp),
        )
        Text(
          text = if (shizukuStatus == ShizukuStatus.CONNECTED) "SHIZUKU API" else "VERIFICAR",
          fontFamily = FontFamily.Monospace,
          fontSize = 10.sp,
          color = TextMuted,
        )
      }
    }
  }
}

@Composable
fun ShizukuAlertBanner(
  shizukuStatus: ShizukuStatus,
  onOpenShizuku: () -> Unit,
  onRequestPermission: () -> Unit,
) {
  AnimatedVisibility(
    visible = shizukuStatus != ShizukuStatus.CONNECTED,
    enter = fadeIn() + expandVertically(),
    exit = fadeOut() + shrinkVertically(),
  ) {
    val isDisconnected = shizukuStatus == ShizukuStatus.DISCONNECTED
    val accent = if (isDisconnected) NeonRed else StatusAmber

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(14.dp))
        .background(accent.copy(alpha = 0.12f))
        .border(1.dp, accent.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Icon(
        imageVector = Icons.Filled.Warning,
        contentDescription = null,
        tint = accent,
        modifier = Modifier.size(22.dp),
      )
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = if (isDisconnected) {
            stringResource(R.string.shizuku_disconnected)
          } else {
            stringResource(R.string.shizuku_permission_needed)
          },
          style = MaterialTheme.typography.titleMedium,
          color = accent,
          fontSize = 13.sp,
        )
        Text(
          text = if (isDisconnected) {
            stringResource(R.string.shizuku_open_warning)
          } else {
            "Conceda a permissão do Shizuku (código 1001) para aplicar ajustes de FPS."
          },
          style = MaterialTheme.typography.bodyMedium,
          color = TextPrimary,
          fontSize = 12.sp,
        )
      }

      Button(
        onClick = if (isDisconnected) onOpenShizuku else onRequestPermission,
        modifier = Modifier
          .height(40.dp)
          .testTag(
            if (isDisconnected) "open_shizuku_button" else "request_shizuku_permission_button"
          ),
        shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(horizontal = 12.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = accent,
          contentColor = if (isDisconnected) Color.White else BgDeepBlack,
        ),
      ) {
        Text(
          text = if (isDisconnected) "Abrir Shizuku" else "Autorizar",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
        )
      }
    }
  }
}

@Composable
fun GameSelectorCard(
  apps: List<InstalledAppInfo>,
  selectedGame: InstalledAppInfo?,
  searchQuery: String,
  isLoading: Boolean,
  onSearchQueryChange: (String) -> Unit,
  onSelectGame: (InstalledAppInfo) -> Unit,
  onRefreshApps: () -> Unit,
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .background(CardSurface)
      .border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
      .padding(14.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.SportsEsports,
          contentDescription = null,
          tint = NeonRed,
          modifier = Modifier.size(18.dp),
        )
        Text(
          text = stringResource(R.string.select_game_title),
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
          color = TextPrimary,
        )
      }

      IconButton(
        onClick = onRefreshApps,
        modifier = Modifier
          .size(36.dp)
          .testTag("refresh_apps_button"),
      ) {
        Icon(
          imageVector = Icons.Filled.Refresh,
          contentDescription = "Atualizar lista",
          tint = TextSecondary,
          modifier = Modifier.size(18.dp),
        )
      }
    }

    OutlinedTextField(
      value = searchQuery,
      onValueChange = onSearchQueryChange,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("game_search_input"),
      placeholder = {
        Text(
          text = stringResource(R.string.search_game_hint),
          color = TextMuted,
          fontSize = 13.sp,
        )
      },
      leadingIcon = {
        Icon(
          imageVector = Icons.Filled.Search,
          contentDescription = null,
          tint = TextSecondary,
        )
      },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { onSearchQueryChange("") }) {
            Icon(
              imageVector = Icons.Filled.Clear,
              contentDescription = "Limpar busca",
              tint = TextSecondary,
            )
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(12.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = BgDeepBlack,
        unfocusedContainerColor = BgDeepBlack,
        focusedBorderColor = NeonRed,
        unfocusedBorderColor = CardBorderSubtle,
        focusedTextColor = TextPrimary,
        unfocusedTextColor = TextPrimary,
        cursorColor = NeonRed,
      ),
    )

    if (isLoading) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(140.dp),
        contentAlignment = Alignment.Center,
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          CircularProgressIndicator(color = NeonRed, modifier = Modifier.size(28.dp))
          Text(
            text = "Escaneando pacotes instalados...",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = TextSecondary,
          )
        }
      }
    } else if (apps.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(110.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(BgDeepBlack),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = "Nenhum app encontrado para \"$searchQuery\"",
          color = TextMuted,
          fontSize = 12.sp,
        )
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(min = 120.dp, max = 196.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        items(apps, key = { it.packageName }) { app ->
          val isSelected = selectedGame?.packageName == app.packageName
          GameRowItem(
            app = app,
            isSelected = isSelected,
            onClick = { onSelectGame(app) },
          )
        }
      }
    }
  }
}

@Composable
private fun GameRowItem(
  app: InstalledAppInfo,
  isSelected: Boolean,
  onClick: () -> Unit,
) {
  val borderColor = when {
    isSelected && app.isRoblox -> VipGold
    isSelected -> NeonRed
    app.isRoblox -> VipGold.copy(alpha = 0.55f)
    else -> CardBorderSubtle
  }
  val bgColor = when {
    isSelected -> CardSurfaceElevated
    app.isRoblox -> Color(0xFF1A1612)
    else -> BgDeepBlack
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(bgColor)
      .border(if (isSelected) 1.5.dp else 1.dp, borderColor, RoundedCornerShape(12.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 10.dp, vertical = 9.dp)
      .testTag("game_item_${app.packageName}"),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    if (app.icon != null) {
      Image(
        bitmap = app.icon,
        contentDescription = app.appName,
        contentScale = ContentScale.Crop,
        modifier = Modifier
          .size(38.dp)
          .clip(RoundedCornerShape(9.dp)),
      )
    } else {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(RoundedCornerShape(9.dp))
          .background(CardSurfaceElevated),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.SportsEsports,
          contentDescription = app.appName,
          tint = NeonRed,
          modifier = Modifier.size(20.dp),
        )
      }
    }

    Column(modifier = Modifier.weight(1f)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(
          text = app.appName,
          style = MaterialTheme.typography.titleMedium,
          fontSize = 14.sp,
          color = TextPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f, fill = false),
        )
        if (app.isRoblox) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(5.dp))
              .background(VipGoldSoft)
              .border(1.dp, VipGold.copy(alpha = 0.7f), RoundedCornerShape(5.dp))
              .padding(horizontal = 5.dp, vertical = 1.dp),
          ) {
            Text(
              text = "ROBLOX DESTAQUE",
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 9.sp,
              color = VipGold,
            )
          }
        }
      }
      Text(
        text = app.packageName,
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        color = TextSecondary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }

    if (isSelected) {
      Icon(
        imageVector = Icons.Filled.CheckCircle,
        contentDescription = "Selecionado",
        tint = if (app.isRoblox) VipGold else NeonRed,
        modifier = Modifier.size(20.dp),
      )
    }
  }
}

@Composable
fun FpsModesSection(
  selectedMode: FpsMode?,
  onSelectMode: (FpsMode) -> Unit,
) {
  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = Icons.Filled.Speed,
        contentDescription = null,
        tint = NeonRed,
        modifier = Modifier.size(18.dp),
      )
      Text(
        text = stringResource(R.string.select_fps_title),
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        color = TextPrimary,
      )
    }

    FpsMode.entries.forEach { mode ->
      val isSelected = selectedMode == mode
      if (mode.isVip) {
        VipFpsModeCard(
          mode = mode,
          isSelected = isSelected,
          onClick = { onSelectMode(mode) },
        )
      } else {
        StandardFpsModeCard(
          mode = mode,
          isSelected = isSelected,
          onClick = { onSelectMode(mode) },
        )
      }
    }
  }
}

@Composable
private fun StandardFpsModeCard(
  mode: FpsMode,
  isSelected: Boolean,
  onClick: () -> Unit,
) {
  val borderColor = if (isSelected) NeonRed else CardBorderSubtle
  val bgColor = if (isSelected) Color(0xFF1D1319) else CardSurface

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(bgColor)
      .border(if (isSelected) 1.5.dp else 1.dp, borderColor, RoundedCornerShape(14.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 14.dp, vertical = 12.dp)
      .testTag("fps_mode_${mode.fpsValue}"),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Box(
      modifier = Modifier
        .size(46.dp)
        .clip(RoundedCornerShape(11.dp))
        .background(if (isSelected) NeonRed else CardSurfaceElevated),
      contentAlignment = Alignment.Center,
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = mode.fpsValue.toString(),
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.ExtraBold,
          fontSize = 15.sp,
          color = if (isSelected) Color.White else NeonRed,
        )
        Text(
          text = "FPS",
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 8.sp,
          color = if (isSelected) Color.White.copy(alpha = 0.9f) else TextMuted,
        )
      }
    }

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = mode.title,
        style = MaterialTheme.typography.titleMedium,
        color = TextPrimary,
      )
      Text(
        text = mode.subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = TextSecondary,
      )
    }

    Box(
      modifier = Modifier
        .size(22.dp)
        .clip(CircleShape)
        .border(2.dp, if (isSelected) NeonRed else TextMuted, CircleShape)
        .padding(4.dp),
      contentAlignment = Alignment.Center,
    ) {
      if (isSelected) {
        Box(
          modifier = Modifier
            .size(10.dp)
            .clip(CircleShape)
            .background(NeonRed),
        )
      }
    }
  }
}

@Composable
private fun VipFpsModeCard(
  mode: FpsMode,
  isSelected: Boolean,
  onClick: () -> Unit,
) {
  val borderBrush = Brush.horizontalGradient(
    colors = if (isSelected) listOf(VipGold, NeonRed, VipGold) else listOf(VipGold.copy(alpha = 0.7f), NeonRed.copy(alpha = 0.7f))
  )
  val bgBrush = Brush.linearGradient(
    colors = if (isSelected) {
      listOf(Color(0xFF2B210B), Color(0xFF280D16), CardSurface)
    } else {
      listOf(Color(0xFF1E190C), Color(0xFF1C0E13), CardSurface)
    }
  )

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .background(bgBrush)
      .border(if (isSelected) 2.dp else 1.2.dp, borderBrush, RoundedCornerShape(16.dp))
      .clickable(onClick = onClick)
      .padding(14.dp)
      .testTag("fps_mode_vip_400"),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(RoundedCornerShape(11.dp))
          .background(
            Brush.linearGradient(listOf(VipGold, NeonRed))
          ),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.WorkspacePremium,
          contentDescription = "VIP",
          tint = BgDeepBlack,
          modifier = Modifier.size(26.dp),
        )
      }

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = mode.title,
          style = MaterialTheme.typography.titleMedium,
          color = VipGold,
          fontWeight = FontWeight.ExtraBold,
        )
        Text(
          text = mode.subtitle,
          style = MaterialTheme.typography.bodyMedium,
          color = TextPrimary.copy(alpha = 0.9f),
        )
      }

      Box(
        modifier = Modifier
          .size(22.dp)
          .clip(CircleShape)
          .border(2.dp, if (isSelected) VipGold else VipGold.copy(alpha = 0.5f), CircleShape)
          .padding(4.dp),
        contentAlignment = Alignment.Center,
      ) {
        if (isSelected) {
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(VipGold),
          )
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      VipFeatureChip("CPU / GPU MAX")
      VipFeatureChip("RAM BOOST")
      VipFeatureChip("FASTFLAGS PRO")
    }
  }
}

@Composable
private fun VipFeatureChip(label: String) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(VipGoldSoft)
      .border(1.dp, VipGold.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
      .padding(horizontal = 7.dp, vertical = 3.dp),
  ) {
    Text(
      text = label,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.Bold,
      fontSize = 9.sp,
      color = VipGold,
    )
  }
}

@Composable
fun LiveTerminalSection(
  logs: List<TerminalLogEntry>,
  onClearLogs: () -> Unit,
) {
  val listState = rememberLazyListState()

  LaunchedEffect(logs.size) {
    if (logs.isNotEmpty()) {
      listState.animateScrollToItem(logs.lastIndex)
    }
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .background(CardSurface)
      .border(1.dp, CardBorderSubtle, RoundedCornerShape(16.dp))
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.Terminal,
          contentDescription = null,
          tint = TerminalGreen,
          modifier = Modifier.size(17.dp),
        )
        Text(
          text = stringResource(R.string.live_terminal),
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 12.sp,
          color = TextPrimary,
        )
      }

      TextButton(
        onClick = onClearLogs,
        modifier = Modifier
          .height(34.dp)
          .testTag("clear_logs_button"),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.DeleteSweep,
          contentDescription = stringResource(R.string.clear_logs),
          tint = NeonRed,
          modifier = Modifier.size(15.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = stringResource(R.string.clear_logs),
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          color = NeonRed,
        )
      }
    }

    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(170.dp)
        .clip(RoundedCornerShape(10.dp))
        .background(TerminalBg)
        .border(1.dp, Color(0xFF1F1F2E), RoundedCornerShape(10.dp))
        .padding(10.dp),
    ) {
      LazyColumn(
        state = listState,
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        items(logs, key = { it.id }) { entry ->
          val levelColor = when (entry.level) {
            LogLevel.SYS -> Color(0xFF64B5F6)
            LogLevel.CMD -> TextSecondary
            LogLevel.OK -> TerminalGreen
            LogLevel.WARN -> StatusAmber
            LogLevel.ERR -> NeonRed
            LogLevel.VIP -> VipGold
            LogLevel.FLAG -> Color(0xFFE040FB)
          }

          Text(
            text = "[${entry.timestamp}] [${entry.level.name}] ${entry.message}",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            color = levelColor,
          )
        }
      }
    }
  }
}

@Composable
fun BottomActionDock(
  selectedGame: InstalledAppInfo?,
  selectedMode: FpsMode?,
  isApplying: Boolean,
  showLaunchGameButton: Boolean,
  onActivateFps: () -> Unit,
  onLaunchGame: () -> Unit,
) {
  Surface(
    color = BgDeepBlack.copy(alpha = 0.96f),
    tonalElevation = 8.dp,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(horizontal = 16.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      HorizontalDivider(color = CardBorderSubtle, thickness = 1.dp)

      AnimatedVisibility(
        visible = showLaunchGameButton && selectedGame != null,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
      ) {
        Button(
          onClick = onLaunchGame,
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("open_game_now_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = VipGold,
            contentColor = BgDeepBlack,
          ),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Launch,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.open_game_now),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            letterSpacing = 0.6.sp,
          )
        }
      }

      val readyToApply = selectedGame != null && selectedMode != null && !isApplying
      Button(
        onClick = onActivateFps,
        enabled = !isApplying,
        modifier = Modifier
          .fillMaxWidth()
          .height(56.dp)
          .testTag("activate_fps_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = if (readyToApply) NeonRed else NeonRed.copy(alpha = 0.65f),
          contentColor = Color.White,
        ),
      ) {
        if (isApplying) {
          CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            strokeWidth = 2.5.dp,
            color = Color.White,
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "APLICANDO ENGINE...",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            letterSpacing = 1.sp,
          )
        } else {
          Icon(
            imageVector = if (selectedMode?.isVip == true) Icons.Filled.Bolt else Icons.Filled.PlayArrow,
            contentDescription = null,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.activate_fps).uppercase(),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 16.sp,
            letterSpacing = 1.2.sp,
          )
        }
      }

      Text(
        text = stringResource(R.string.credits_raylan),
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        color = TextMuted,
        modifier = Modifier.align(Alignment.CenterHorizontally),
      )
    }
  }
}
