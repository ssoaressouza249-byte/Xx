package com.raylan.owerotmx.viewmodel

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.owerotmx.model.FpsMode
import com.raylan.owerotmx.model.InstalledAppInfo
import com.raylan.owerotmx.model.LogLevel
import com.raylan.owerotmx.model.ShizukuStatus
import com.raylan.owerotmx.model.TerminalLogEntry
import com.raylan.owerotmx.shizuku.ShizukuExecutor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class OwerUiState(
  val shizukuStatus: ShizukuStatus = ShizukuStatus.DISCONNECTED,
  val isLoadingApps: Boolean = true,
  val selectedGame: InstalledAppInfo? = null,
  val selectedFpsMode: FpsMode? = null,
  val searchQuery: String = "",
  val isApplying: Boolean = false,
  val isRestoring: Boolean = false,
  val showLaunchGameButton: Boolean = false,
  val lastAppliedSummary: String? = null,
  val logs: List<TerminalLogEntry> = emptyList(),
)

class OwerViewModel(application: Application) : AndroidViewModel(application) {

  private val logCounter = AtomicLong(0L)
  private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

  private val _uiState = MutableStateFlow(OwerUiState())
  val uiState: StateFlow<OwerUiState> = _uiState.asStateFlow()

  private val _allApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
  private val _searchQuery = MutableStateFlow("")

  val filteredApps: StateFlow<List<InstalledAppInfo>> =
    combine(_allApps, _searchQuery) { apps, query ->
      val trimmed = query.trim()
      if (trimmed.isEmpty()) {
        apps
      } else {
        apps.filter {
          it.appName.contains(trimmed, ignoreCase = true) ||
            it.packageName.contains(trimmed, ignoreCase = true)
        }
      }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

  private var permissionRequestedOnOpen = false

  init {
    appendLog(LogLevel.SYS, "OWER OTMX ENGINE V1 inicializado.")
    refreshShizukuStatus(autoRequestPermission = false)
    loadInstalledApps()
  }

  fun onBinderReceived() {
    appendLog(LogLevel.SYS, "Shizuku binder recebido.")
    refreshShizukuStatus(autoRequestPermission = true)
  }

  fun onBinderDead() {
    _uiState.update { it.copy(shizukuStatus = ShizukuStatus.DISCONNECTED) }
    appendLog(LogLevel.WARN, "Shizuku desconectado (binder encerrado).")
  }

  fun onPermissionResult(requestCode: Int, grantResult: Int) {
    if (requestCode == ShizukuExecutor.SHIZUKU_PERMISSION_REQUEST_CODE) {
      val granted = grantResult == PackageManager.PERMISSION_GRANTED
      val status = ShizukuExecutor.checkStatus()
      _uiState.update { it.copy(shizukuStatus = status) }
      if (granted) {
        appendLog(LogLevel.OK, "Permissão Shizuku concedida.")
      } else {
        appendLog(LogLevel.ERR, "Permissão Shizuku negada pelo usuário.")
      }
    }
  }

  fun refreshShizukuStatus(autoRequestPermission: Boolean) {
    val status = ShizukuExecutor.checkStatus()
    val previousStatus = _uiState.value.shizukuStatus
    _uiState.update { it.copy(shizukuStatus = status) }

    when (status) {
      ShizukuStatus.CONNECTED -> {
        if (previousStatus != ShizukuStatus.CONNECTED) {
          appendLog(LogLevel.OK, "Shizuku conectado e autorizado.")
        }
      }
      ShizukuStatus.PERMISSION_NEEDED -> {
        if (autoRequestPermission && !permissionRequestedOnOpen) {
          permissionRequestedOnOpen = true
          appendLog(LogLevel.WARN, "Solicitando permissão Shizuku (código 1001)...")
          ShizukuExecutor.requestPermissionIfNeeded()
        } else if (previousStatus != ShizukuStatus.PERMISSION_NEEDED) {
          appendLog(LogLevel.WARN, "Shizuku conectado, aguardando permissão.")
        }
      }
      ShizukuStatus.DISCONNECTED -> {
        if (previousStatus != ShizukuStatus.DISCONNECTED) {
          appendLog(
            LogLevel.WARN,
            "Shizuku desligado. Abra ${ShizukuExecutor.SHIZUKU_PACKAGE} para iniciar o serviço.",
          )
        }
      }
    }
  }

  fun requestShizukuPermissionManually() {
    val status = ShizukuExecutor.checkStatus()
    _uiState.update { it.copy(shizukuStatus = status) }
    if (status == ShizukuStatus.PERMISSION_NEEDED) {
      appendLog(LogLevel.SYS, "Requisitando permissão Shizuku (1001)...")
      ShizukuExecutor.requestPermissionIfNeeded()
    } else if (status == ShizukuStatus.DISCONNECTED) {
      appendLog(LogLevel.ERR, "Serviço Shizuku offline. Inicie moe.shizuku.privileged.api primeiro.")
    }
  }

  fun openShizukuApp() {
    val context = getApplication<Application>()
    runCatching {
      val launchIntent = context.packageManager.getLaunchIntentForPackage(ShizukuExecutor.SHIZUKU_PACKAGE)
      if (launchIntent != null) {
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        appendLog(LogLevel.SYS, "Abrindo Shizuku (${ShizukuExecutor.SHIZUKU_PACKAGE})...")
      } else {
        appendLog(
          LogLevel.ERR,
          "App Shizuku (${ShizukuExecutor.SHIZUKU_PACKAGE}) não encontrado neste dispositivo.",
        )
      }
    }.onFailure {
      appendLog(LogLevel.ERR, "Falha ao abrir Shizuku: ${it.message}")
    }
  }

  fun loadInstalledApps() {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoadingApps = true) }
      val apps = withContext(Dispatchers.IO) {
        runCatching {
          val context = getApplication<Application>()
          val pm = context.packageManager
          val ownPkg = context.packageName
          val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)

          packages
            .asSequence()
            .filter { appInfo ->
              appInfo.packageName != ownPkg &&
                (appInfo.packageName == ShizukuExecutor.ROBLOX_PACKAGE ||
                  pm.getLaunchIntentForPackage(appInfo.packageName) != null)
            }
            .map { appInfo ->
              val label = runCatching {
                appInfo.loadLabel(pm).toString().ifBlank { appInfo.packageName }
              }.getOrDefault(appInfo.packageName)
              val iconBitmap = runCatching {
                drawableToScaledBitmap(appInfo.loadIcon(pm))
              }.getOrNull()

              InstalledAppInfo(
                appName = label,
                packageName = appInfo.packageName,
                icon = iconBitmap,
                isRoblox = appInfo.packageName == ShizukuExecutor.ROBLOX_PACKAGE,
              )
            }
            .sortedWith(
              compareByDescending<InstalledAppInfo> { it.isRoblox }
                .thenBy { it.appName.lowercase(Locale.getDefault()) }
            )
            .toList()
        }.getOrElse { emptyList() }
      }

      _allApps.value = apps
      _uiState.update { state ->
        val robloxApp = apps.firstOrNull { it.isRoblox }
        val updatedSelection = state.selectedGame ?: robloxApp
        state.copy(
          isLoadingApps = false,
          selectedGame = updatedSelection,
        )
      }
      val robloxFound = apps.any { it.isRoblox }
      appendLog(
        LogLevel.SYS,
        if (robloxFound) {
          "${apps.size} apps carregados. Roblox (com.roblox.client) destacado no topo."
        } else {
          "${apps.size} apps carregados via PackageManager."
        },
      )
    }
  }

  fun updateSearchQuery(query: String) {
    _searchQuery.value = query
    _uiState.update { it.copy(searchQuery = query) }
  }

  fun selectGame(app: InstalledAppInfo) {
    _uiState.update {
      it.copy(
        selectedGame = app,
        showLaunchGameButton = false,
      )
    }
    val tag = if (app.isRoblox) " [ROBLOX FASTFLAGS READY]" else ""
    appendLog(LogLevel.SYS, "Alvo selecionado: ${app.appName} (${app.packageName})$tag")
  }

  fun selectFpsMode(mode: FpsMode) {
    _uiState.update { it.copy(selectedFpsMode = mode) }
    val level = if (mode.isVip) LogLevel.VIP else LogLevel.SYS
    appendLog(level, "Perfil preparado: ${mode.title} — clique em 'Ativo FPS' para aplicar.")
  }

  fun activateFps() {
    val currentState = _uiState.value
    if (currentState.isApplying || currentState.isRestoring) return

    val game = currentState.selectedGame
    val mode = currentState.selectedFpsMode

    if (game == null) {
      appendLog(LogLevel.ERR, "Selecione um jogo antes de ativar o FPS.")
      return
    }
    if (mode == null) {
      appendLog(LogLevel.ERR, "Selecione um modo de FPS antes de clicar em Ativo FPS.")
      return
    }

    val status = ShizukuExecutor.checkStatus()
    _uiState.update { it.copy(shizukuStatus = status) }
    if (status != ShizukuStatus.CONNECTED) {
      if (status == ShizukuStatus.PERMISSION_NEEDED) {
        appendLog(LogLevel.WARN, "Permissão Shizuku pendente. Solicitando autorização...")
        ShizukuExecutor.requestPermissionIfNeeded()
      } else {
        appendLog(
          LogLevel.ERR,
          "Shizuku desligado. Abra moe.shizuku.privileged.api para executar comandos.",
        )
      }
      return
    }

    viewModelScope.launch {
      _uiState.update { it.copy(isApplying = true, showLaunchGameButton = false) }
      val headerLevel = if (mode.isVip) LogLevel.VIP else LogLevel.SYS
      appendLog(
        headerLevel,
        "Iniciando engine ${if (mode.isVip) "VIP MÁXIMO 400 FPS" else "${mode.fpsValue} FPS"} em ${game.packageName}...",
      )

      var successCount = 0
      var totalCount = 0

      withContext(Dispatchers.IO) {
        val commands = ShizukuExecutor.buildFpsCommands(game.packageName, mode)
        for (cmd in commands) {
          totalCount++
          appendLog(if (mode.isVip) LogLevel.VIP else LogLevel.CMD, "$ $cmd")
          val result = ShizukuExecutor.runShellCommand(cmd)
          if (result.success) {
            successCount++
            val details = result.output.ifBlank { "exit=0" }
            appendLog(LogLevel.OK, "OK ($details)")
          } else {
            val reason = result.error.ifBlank { "exit=${result.exitCode}" }
            appendLog(LogLevel.WARN, "Aviso: $reason")
          }
        }

        if (game.isRoblox || game.packageName == ShizukuExecutor.ROBLOX_PACKAGE) {
          totalCount++
          val fastFlagsJson = ShizukuExecutor.buildRobloxFastFlagsJson(mode)
          appendLog(LogLevel.FLAG, "ClientAppSettings.json -> $fastFlagsJson")
          val writeCmd = ShizukuExecutor.buildRobloxFastFlagsCommand(game.packageName, fastFlagsJson)
          appendLog(LogLevel.CMD, "$ $writeCmd")
          val flagResult = ShizukuExecutor.runShellCommand(writeCmd)
          if (flagResult.success) {
            successCount++
            appendLog(LogLevel.OK, "FastFlags gravadas em /sdcard/Android/data/${game.packageName}/files/ClientSettings/")
          } else {
            appendLog(LogLevel.WARN, "FastFlags aviso: ${flagResult.error.ifBlank { "exit=${flagResult.exitCode}" }}")
          }
        }
      }

      val summary = "${game.appName} • ${mode.fpsValue} FPS ($successCount/$totalCount comandos)"
      appendLog(LogLevel.OK, "Otimização finalizada: $summary")
      _uiState.update {
        it.copy(
          isApplying = false,
          showLaunchGameButton = true,
          lastAppliedSummary = summary,
        )
      }
    }
  }

  fun restoreDefault() {
    val currentState = _uiState.value
    if (currentState.isApplying || currentState.isRestoring) return

    val status = ShizukuExecutor.checkStatus()
    _uiState.update { it.copy(shizukuStatus = status) }

    if (status != ShizukuStatus.CONNECTED) {
      _uiState.update {
        it.copy(
          selectedFpsMode = null,
          showLaunchGameButton = false,
          lastAppliedSummary = null,
        )
      }
      appendLog(
        LogLevel.WARN,
        "Seleção limpa localmente. Conecte o Shizuku (moe.shizuku.privileged.api) para restaurar props do sistema.",
      )
      return
    }

    viewModelScope.launch {
      _uiState.update { it.copy(isRestoring = true) }
      val targetPkg = currentState.selectedGame?.packageName
      appendLog(LogLevel.SYS, "Restaurando configurações padrão do sistema...")

      withContext(Dispatchers.IO) {
        val commands = ShizukuExecutor.buildRestoreCommands(targetPkg)
        for ((level, cmd) in commands) {
          appendLog(level, "$ $cmd")
          val res = ShizukuExecutor.runShellCommand(cmd)
          if (res.success) {
            appendLog(LogLevel.OK, "Restaurado (exit=0)")
          } else {
            appendLog(LogLevel.WARN, "Aviso: ${res.error.ifBlank { "exit=${res.exitCode}" }}")
          }
        }
      }

      _uiState.update {
        it.copy(
          isRestoring = false,
          selectedFpsMode = null,
          showLaunchGameButton = false,
          lastAppliedSummary = null,
        )
      }
      appendLog(LogLevel.OK, "Padrão de fábrica restaurado com sucesso.")
    }
  }

  fun launchSelectedGame() {
    val game = _uiState.value.selectedGame ?: return
    val context = getApplication<Application>()
    runCatching {
      val launchIntent = context.packageManager.getLaunchIntentForPackage(game.packageName)
      if (launchIntent != null) {
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        appendLog(LogLevel.OK, "Iniciando ${game.appName} (${game.packageName})...")
      } else {
        appendLog(LogLevel.ERR, "Não há Activity inicializável para ${game.packageName}.")
      }
    }.onFailure {
      appendLog(LogLevel.ERR, "Erro ao abrir jogo: ${it.message}")
    }
  }

  fun clearLogs() {
    _uiState.update { it.copy(logs = emptyList()) }
    appendLog(LogLevel.SYS, "Logs limpos. Terminal pronto.")
  }

  private fun appendLog(level: LogLevel, message: String) {
    val entry = TerminalLogEntry(
      id = logCounter.incrementAndGet(),
      timestamp = timeFormat.format(Date()),
      level = level,
      message = message,
    )
    _uiState.update { state ->
      val updated = (state.logs + entry).takeLast(200)
      state.copy(logs = updated)
    }
  }

  private fun drawableToScaledBitmap(drawable: Drawable): ImageBitmap {
    val targetSize = 96
    if (drawable is BitmapDrawable && drawable.bitmap != null) {
      val scaled = Bitmap.createScaledBitmap(drawable.bitmap, targetSize, targetSize, true)
      return scaled.asImageBitmap()
    }
    val bitmap = Bitmap.createBitmap(targetSize, targetSize, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)
    return bitmap.asImageBitmap()
  }
}
